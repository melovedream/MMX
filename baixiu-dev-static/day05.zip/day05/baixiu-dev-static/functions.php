<?php

	function query($sql){
	  //1.连接数据库
	  $conn = mysqli_connect("127.0.0.1","root","root","db_baixiu");

	  if(!$conn){
	    die("数据库连接失败");
	  }

	  //2.定义sql语句
	  //$sql = " select * from categories where id != 1 ";

	  //3.执行sql语句，查询导航分类信息
	  $result = mysqli_query($conn,$sql);

	  //4.读取所有分类数据保存到一个数组中
	  //声明一个数组，用来保存所有的分类数据
	  $arr = [];
	  //循环读取$result数据集中的所有分类数据
	  while($row = mysqli_fetch_assoc($result) ){
	    //将读取到的每一个分类数据添加到数组arr中。
	    $arr[] = $row;
	  }

	  //将查询的结果作为函数的返回值
	  return $arr;
	}

	//执行增删改语句并返回结果
	function execute($sql){
		//1.连接数据库
	  $conn = mysqli_connect("127.0.0.1","root","root","db_baixiu");

	  if(!$conn){
	    die("数据库连接失败");
	  }

	  

	  //2.执行sql语句，查询导航分类信息
	  $result = mysqli_query($conn,$sql);

	  if($result){
	  	return $result;
	  }else{
	  	return "执行错误：".mysqli_error($conn);
	  }

	  
	}
	

?>