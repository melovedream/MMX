<?php
  //获取地址栏中id参数的值
  $id = $_GET["id"];

  //include "functions.php";

  

  //连接数据库
  // $conn = mysqli_connect("127.0.0.1","root","root","db_baixiu");

  // if(!$conn){
  //   die("数据库连接失败");
  // }

  // //定义sql语句
  // $sql = " select posts.id, posts.title,content,created,views,likes,users.nickname,categories.name ,
  // (select count(*) from comments where post_id = posts.id)as commentsCount
  // from posts 
  // inner join categories on posts.category_id = categories.id
  // inner join users on posts.user_id = users.id
  // where categories.id != 1 and categories.id = {$id}
  // order by created desc
  // limit 10 ";

  // //执行sql语句
  // $result = mysqli_query($conn,$sql);

  // //定义一个数组保存所有查询到的数据
  // $postArr = [];

  // //循环读取结果集中的数据并添加到数组中
  // while($row = mysqli_fetch_assoc($result) ){
  //   $postArr[] = $row;
  // }

  // print_r($postArr);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>阿里百秀-发现生活，发现美!</title>
  <link rel="stylesheet" href="static/assets/css/style.css">
  <link rel="stylesheet" href="static/assets/vendors/font-awesome/css/font-awesome.css">
</head>
<body>
  <div class="wrapper">
    <div class="topnav">
      <ul>
        <li><a href="javascript:;"><i class="fa fa-glass"></i>奇趣事</a></li>
        <li><a href="javascript:;"><i class="fa fa-phone"></i>潮科技</a></li>
        <li><a href="javascript:;"><i class="fa fa-fire"></i>会生活</a></li>
        <li><a href="javascript:;"><i class="fa fa-gift"></i>美奇迹</a></li>
      </ul>
    </div>
    <?php include_once "public/_header.php" ?>
    <?php include_once "public/_aside.php" ?>
    <div class="content">
      <div class="panel new">
        <h3><?php 
            $postArr = query(" select posts.id, posts.title,content,created,views,likes,users.nickname,categories.name ,
             (select count(*) from comments where post_id = posts.id)as commentsCount
             from posts 
             inner join categories on posts.category_id = categories.id
             inner join users on posts.user_id = users.id
             where categories.id != 1 and categories.id = {$id}
             order by created desc
             limit 10  ");

            //判断一下文章数组是否为空，如果为空，说明该分类没有文章
            if( empty($postArr) ){
              echo "当前分类没有文章";
            }else{
              //如果有文章，那么就获取文章数组中的第一篇文章的分类名称即可
              echo $postArr[0]["name"];
            }
         ?></h3>
        <?php foreach($postArr as $v){  ?>
          <div class="entry">
            <div class="head">
              <a href="detail.php?postId=<?php echo $v["id"]; ?>"><?php echo $v["title"]; ?></a>
            </div>
            <div class="main">
              <p class="info"><?php echo $v["nickname"]; ?> 发表于 <?php echo $v["created"]; ?></p>
              <p class="brief"><?php echo $v["content"]; ?></p>
              <p class="extra">
                <span class="reading">阅读(<?php echo $v["views"]; ?>)</span>
                <span class="comment">评论(<?php echo $v["commentsCount"]; ?>)</span>
                <a href="javascript:;" class="like">
                  <i class="fa fa-thumbs-up"></i>
                  <span>赞(<?php echo $v["likes"]; ?>)</span>
                </a>
                <a href="javascript:;" class="tags">
                  分类：<span><?php echo $v["name"]; ?></span>
                </a>
              </p>
              <a href="javascript:;" class="thumb">
                <img src="static/uploads/hots_2.jpg" alt="">
              </a>
            </div>
          </div>
        <?php } ?>
      
        <div class="loadmore">
          <span class="btn">加载更多</span>
        </div>


      </div>
    </div>
    <div class="footer">
      <p>© 2016 XIU主题演示 本站主题由 themebetter 提供</p>
    </div>
  </div>
  <script src="./static/assets/vendors/jquery/jquery.js"></script>
  <script src="./static/assets/vendors/nprogress/nprogress.js"></script>
  <script src="./static/assets/vendors/art-template/template-web.js"></script>

  <script type="text/template" id="list">
      {{each items as value index}}
      <div class="entry">
          <div class="head">
            <a href="detail.php?postId={{value.id}}">{{value.title}}</a>
          </div>
          <div class="main">
            <p class="info">{{value.nickname}} 发表于 {{value.created}}</p>
            <p class="brief">{{value.content}}</p>
            <p class="extra">
              <span class="reading">阅读({{value.views}})</span>
              <span class="comment">评论({{value.commentsCount}})</span>
              <a href="javascript:;" class="like">
                <i class="fa fa-thumbs-up"></i>
                <span>赞({{value.likes}})</span>
              </a>
              <a href="javascript:;" class="tags">
                分类：<span>{{value.name}}</span>
              </a>
            </p>
            <a href="javascript:;" class="thumb">
              <img src="static/uploads/hots_2.jpg" alt="">
            </a>
          </div>
        </div>
        {{/each}}
  </script>

  <script>
    $(function(){
      //默认情况下已经展示了第一页的10篇文章
        var page = 1;
      //给加载更多按钮添加点击事件
      $(".loadmore .btn").on("click",function(){
        //给后台接口发送请求，获取到更多的文章信息
        //默认情况下页面中展示了10页数据，如果点击了加载更多，就应该加载11~20的数据
        
        //当点击加载更多的按钮的时候，页码+1
        page=page+1;

        //当点击加载更多的按钮的时候，获取地址栏中的分类编号信息
        //创建URLSearchParams对象
        var x = new URLSearchParams(location.search);
        //调用URLSearchParams对象的get方法，并传递需要获取的参数的键，得到键对应的值
        var categoryId = x.get("id");

        $.ajax({
          url:"api/_getMorePost.php",
          data:{categoryId:categoryId,page:page,pageSize:100},
          dataType:"json",
          success:function(res){
            // console.log(res);
            //将接口返回的数据通过模板引擎渲染到页面中展示

            var html = template("list",{items:res});
            // console.log(html);

            //在.loadmore元素前面插入html字符串
            $(".loadmore").before(html);

            //如果没有数据了，就不要再发送请求了
            if(res.length == 0){
              // 移除掉 加载更多按钮的点击事件
              //将加载更多按钮的文字改变一下
              $(".loadmore .btn").off("click").html("没有更多的文章了");
            }
          }
        })


      })
    })
  </script>
</body>
</html>