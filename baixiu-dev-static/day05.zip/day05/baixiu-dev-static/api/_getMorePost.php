<?php
	//获取到相应分类的更多文章信息
	//要求前端发送分类的id
	//考虑要求前端发送一个页码过来
	//再要求前端发送一个每页的数据总量
	$categoryId = $_GET["categoryId"];
	$page = $_GET["page"];
	$pageSize = $_GET["pageSize"];

	//根据页码计算查询数据的偏移行数
	$offset = ($page - 1)*$pageSize;

	$sql = " select posts.id, posts.title,content,created,views,likes,users.nickname,categories.name ,
             (select count(*) from comments where post_id = posts.id)as commentsCount
             from posts 
             inner join categories on posts.category_id = categories.id
             inner join users on posts.user_id = users.id
             where categories.id != 1 and categories.id = {$categoryId}
             order by created desc
             limit $offset,$pageSize  ";

    //引入functions.php
    include_once "../functions.php";
    //调用query函数执行sql语句，得到数组结果
    $arr = query( $sql );

    //因为_getMorePost.php是一个接口文件，最终是要返回前端一段json格式的字符串
   	//所以需要将数组转换为json格式的字符串然后输出即可
   	echo json_encode($arr);

?>