<?php
	//如果想要查询某一篇文章的信息，那么必须要前端发送文章的id
	$postId = $_POST["postId"];
	//定义查询文章详情的sql语句
	$sql = " select posts.title,content,created,views,likes,users.nickname,categories.name 
             from posts 
             inner join categories on posts.category_id = categories.id
             inner join users on posts.user_id = users.id
             where categories.id != 1 and posts.id = {$postId} ";

    include_once "../functions.php";
    //调用query函数查询文章的详情
    $postArr = query( $sql );

    if(empty($postArr)){
    	//如果$postArr为空，说明没有文章，就返回错误提示的讯息给前端
    	$res = [ "code"=>404 , "msg"=>"没有查询到编号对应的文章" ];
    }else{
    	//正常返回讯息给前端
    	$res = [ "code"=>200 , "msg"=>"查询成功","data"=>$postArr];
    }
    //将数组转换为json格式字符串直接输出
    echo json_encode($res);
?>