<?php
  //后台所有的页面都是必须先登录后使用
  //如果没有登录就应该调到登录页面去做登录
  session_start();

  if( !(isset($_SESSION["isLogin"])  && $_SESSION["isLogin"]==="true") )
  {
    //用户没有登录，跳到登录页面
    header("Location:login.php");
  }
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <title>Categories &laquo; Admin</title>
  <link rel="stylesheet" href="../static/assets/vendors/bootstrap/css/bootstrap.css">
  <link rel="stylesheet" href="../static/assets/vendors/font-awesome/css/font-awesome.css">
  <link rel="stylesheet" href="../static/assets/vendors/nprogress/nprogress.css">
  <link rel="stylesheet" href="../static/assets/css/admin.css">
  <script src="../static/assets/vendors/nprogress/nprogress.js"></script>
</head>
<body>
  <script>NProgress.start()</script>

  <div class="main">
    <nav class="navbar">
      <button class="btn btn-default navbar-btn fa fa-bars"></button>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="profile.php"><i class="fa fa-user"></i>个人中心</a></li>
        <li><a href="login.php"><i class="fa fa-sign-out"></i>退出</a></li>
      </ul>
    </nav>
    <div class="container-fluid">
      <div class="page-title">
        <h1>分类目录</h1>
      </div>
      <!-- 有错误信息时展示 -->
      <div class="alert alert-danger" style="display: none">
        <strong>错误！</strong><span id="msg">发生XXX错误</span>
      </div>
      <div class="row">
        <div class="col-md-4">
          <form id="frm">
            <h2>添加新分类目录</h2>
            <div class="form-group">
              <label for="name">名称</label>
              <input id="name" class="form-control" name="name" type="text" placeholder="分类名称">
            </div>
            <div class="form-group">
              <label for="slug">别名</label>
              <input id="slug" class="form-control" name="slug" type="text" placeholder="slug">
              <p class="help-block">https://zce.me/category/<strong>slug</strong></p>
            </div>

            <div class="form-group">
              <label for="classname">类名</label>
              <input id="classname" class="form-control" name="classname" type="text" placeholder="类名">
              <p class="help-block">https://zce.me/category/<strong>类名</strong></p>
            </div>

            <div class="form-group">
              <span id="btnAdd" class="btn btn-primary">添加</span>
              <span style="display: none" id="btnEdit" class="btn btn-primary">编辑完成</span>
              <span style="display: none" id="btnCancel" class="btn btn-primary">取消编辑</span>
            </div>
          </form>
        </div>
        <div class="col-md-8">
          <div class="page-action">
            <!-- show when multiple checked -->
            <a id="delAll" class="btn btn-danger btn-sm" href="javascript:;" style="display: none">批量删除</a>
          </div>
          <table class="table table-striped table-bordered table-hover">
            <thead>
              <tr>
                <th class="text-center" width="40"><input type="checkbox"></th>
                <th>名称</th>
                <th>Slug</th>
                <th>类名</th>
                <th class="text-center" width="100">操作</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="text-center"><input type="checkbox"></td>
                <td>未分类</td>
                <td>uncategorized</td>
                <td>fa-fire</td>
                <td class="text-center">
                  <a href="javascript:;" class="btn btn-info btn-xs">编辑</a>
                  <a href="javascript:;" class="btn btn-danger btn-xs">删除</a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="aside">
    <div class="profile">
      <img class="avatar" src="../static/uploads/avatar.jpg">
      <h3 class="name">布头儿</h3>
    </div>
    <ul class="nav">
      <li>
        <a href="index.php"><i class="fa fa-dashboard"></i>仪表盘</a>
      </li>
      <li class="active">
        <a href="#menu-posts" data-toggle="collapse">
          <i class="fa fa-thumb-tack"></i>文章<i class="fa fa-angle-right"></i>
        </a>
        <ul id="menu-posts" class="collapse in">
          <li><a href="posts.php">所有文章</a></li>
          <li><a href="post-add.php">写文章</a></li>
          <li class="active"><a href="categories.php">分类目录</a></li>
        </ul>
      </li>
      <li>
        <a href="comments.php"><i class="fa fa-comments"></i>评论</a>
      </li>
      <li>
        <a href="users.php"><i class="fa fa-users"></i>用户</a>
      </li>
      <li>
        <a href="#menu-settings" class="collapsed" data-toggle="collapse">
          <i class="fa fa-cogs"></i>设置<i class="fa fa-angle-right"></i>
        </a>
        <ul id="menu-settings" class="collapse">
          <li><a href="nav-menus.php">导航菜单</a></li>
          <li><a href="slides.php">图片轮播</a></li>
          <li><a href="settings.php">网站设置</a></li>
        </ul>
      </li>
    </ul>
  </div>

  <script src="../static/assets/vendors/jquery/jquery.js"></script>
  <script src="../static/assets/vendors/bootstrap/js/bootstrap.js"></script>
  <script>NProgress.done()</script>
</body>

  <script src="../static/assets/vendors/jquery/jquery.js"></script>
  <script src="../static/assets/vendors/nprogress/nprogress.js"></script>
  <script src="../static/assets/vendors/art-template/template-web.js"></script>
  <script src="../static/assets/vendors/bootstrap/js/bootstrap.js"></script>

  <script type="text/template" id="category">
    <% for(var i=0;i<data.length;i++){ %>        
      <tr data-id="<%=data[i].id%>">
        <td class="text-center"><input type="checkbox"></td>
        <td><%=data[i].name%></td>
        <td><%=data[i].slug%></td>
        <td><%=data[i].classname%></td>
        <td class="text-center">
          <a href="javascript:;" class="btn btn-info btn-xs edit">编辑</a>
          <a href="javascript:;" class="btn btn-danger btn-xs del">删除</a>
        </td>
      </tr>
    <% } %>
  </script>
  <script>
    $(function(){
      //声明一个全局变量用来保存分类的id
      var categoryId = null;

      //发送ajax请求_getUserAvatar接口，获取到头像信息
      $.ajax({
        dataType:"json",
        url:"api/_getUserAvatar.php",
        success:function(res){
          $(".aside .profile .avatar").attr("src", res.data[0].avatar );
          $(".aside .profile .name").html( res.data[0].nickname );
        }
      })

      $("#btnLogout").on("click",function(){
        //发送请求给后台完成登出的操作。
        $.ajax({
          url:"api/_logout.php",
          success:function(){
            location.href = "login.php";
          }
        })
      })

      //发送请求到_getCategory.php 获取到所有的分类数据并展示在页面的表格中
      $.ajax({
        type:"post",
        url:"api/_getCategory.php",
        //如果添加了dataType:"json"，jquery就会将服务器返回的json格式字符串转换为js对象
        //使用  JSON.parse() 做转换
        dataType:"json",
        success:function(res){
          console.log(res);
          console.log(typeof res);
          //调用template函数来生成html
          var html = template("category",res);

          // console.log(html);
          $("tbody").html(html);
        }
      })

      //给添加按钮注册点击事件，当点击添加按钮的时候，获取到用户输入的名称，别名，类名
      $("#btnAdd").on("click",function(){
        //获取名称，别名，类名文本框的值。
        var name = $("#name").val();
        var slug = $("#slug").val();
        var classname = $("#classname").val();

        //验证
        if(name.trim() == ""){
          $(".alert").show().find("#msg").text("请输入分类名称");
          return;
        }else if(slug.trim() == ""){
          $(".alert").show().find("#msg").text("请输入分类别名");
          return;
        }else if(classname.trim() == ""){
          $(".alert").show().find("#msg").text("请输入分类图标类名");
          return;
        }

        //发送ajax请求完成添加的操作
        $.ajax({
          url:"api/_addCategory.php",
          type:"post",
          data:{ name:name , slug:slug , classname:classname },
          dataType:"json",
          success:function(res){

            console.log(res);
            if(res.code != 200){
              $(".alert").show().find("#msg").text(res.msg);
            }else{
              // $("#frm")[0].reset();
              location.reload();
            }
          }
        })


      })

      //当用户点击右侧表格中的编辑按钮的时候，显示编辑操作的内容
      //注意：如果不是页面中默认就有的元素，是后续通过代码生成的元素，就必须
      //通过事件委托的形式来注册事件
      // $(".edit").on("click",function(){
      //   alert(123);
      // })
      $("table").on("click",".edit",function(){
        // alert(123);
        //隐藏添加按钮，显示编辑完成，取消编辑按钮
        $("#btnAdd").hide();
        $("#btnEdit").show();
        $("#btnCancel").show();

        //还需要将表格中对应的数据填入到文本框中
        var tr = $(this).parents("tr");
        //将tr中保存的自定义属性data-id获取并保存在categoryId变量中
        categoryId = tr.attr("data-id");
        //获取编辑按钮对应的那一行中的分类名称，别名，类名数据
        var name = tr.find("td").eq(1).text();
        var slug = tr.find("td").eq(2).text();
        var classname = tr.find("td").eq(3).text();
        //将数据填入到文本框
        $("#name").val( name );
        $("#slug").val( slug );
        $("#classname").val( classname );
      })

      //当用户点击取消编辑按钮的时候
      $("#btnCancel").on("click",function(){
        //1.隐藏 编辑完成按钮，取消编辑按钮，  显示添加按钮
        $("#btnAdd").show();
        $("#btnEdit").hide();
        $("#btnCancel").hide();

        //2.把所有文本框的值清空
        $("#name").val("");
        $("#slug").val("");
        $("#classname").val("");
      })

      //当用户点击编辑完成按钮的时候，
      $("#btnEdit").on("click",function(){
        //console.log(categoryId);
        //1.收集用户在文本框输入的数据
        var name = $("#name").val();
        var slug = $("#slug").val();
        var classname = $("#classname").val();
        //验证
        if(name.trim() == ""){
          $(".alert").show().find("#msg").text("请输入分类名称");
          return;
        }else if(slug.trim() == ""){
          $(".alert").show().find("#msg").text("请输入分类别名");
          return;
        }else if(classname.trim() == ""){
          $(".alert").show().find("#msg").text("请输入分类图标类名");
          return;
        }
        //3.发送ajax请求更新数据
        $.ajax({
          url:"api/_updateCategory.php",
          type:"post",
          dataType:"json",
          data:{ categoryId:categoryId , name:name,slug:slug,classname:classname },
          success:function(res){
            if(res.code == 200){
              location.reload();
            }else{
              $(".alert").show().find("#msg").text(res.msg);
            }
          }
        })
      })

      //给删除按钮添加点击事件
      $("table").on("click",".del",function(){
        //获取到你点击的那一行分类的id
        var id = $(this).parents("tr").attr("data-id");

        //发送ajax进行删除的操作
        $.ajax({
          type:"post",
          data:{categoryId : id},
          dataType:"json",
          url:"api/_deleteCategory.php",
          success:function(res){
            if(res.code == 200){
              location.reload();
            }else{
              $(".alert").show().find("#msg").text(res.msg);
            }
          }
        })

      })

      //全选功能
      $("thead input").on("click",function(){

        //prop 和 attr的区别
        //prop可以设置dom对象原本就有的属性，不能设置自定义属性，而attr可以设置自定义属性
        //attr的两个参数都必须是字符串类型的  $("div").attr("align","center")
        //prop的第二个参数可以是bool类型的
        var myCheck = $(this).prop("checked");
        $("tbody input").prop("checked" , myCheck);

        //判断全选按钮是否选中，对应显示批量删除按钮
        if(myCheck){
          $("#delAll").show();
        }else{
          $("#delAll").hide();
        }


      })

      //当选中所有的小按钮时候，全选按钮也要选中
      $("table").on("click","tbody input",function(){

        if( $("tbody input").length == $("tbody input:checked").length ){
          $("thead input").prop("checked",true);
        }else{
          $("thead input").prop("checked",false);
        }

        if( $("tbody input:checked").length >= 2){
          $("#delAll").show();
        }else{
          $("#delAll").hide();
        }


      })


      //给批量删除按钮添加事件
      $("#delAll").on("click",function(){
        //获取到需要删除的所有分类的id
        //获取所有选中的分类
        var cks = $("tbody input:checked");
        var ids = [];
        //根据选中的复选框来找到复选框所在的那一行，然后获取行中的data-id属性的值
        for(var i=0;i<cks.length;i++){
          var id = $(cks[i]).parents("tr").attr("data-id");
          ids.push(id);
        }
        //发送ajax进行批量删除
        $.ajax({
          type:"post",
          data:{ ids : ids },
          dataType:"json",
          url:"api/_delAllCategory.php",
          success:function(res){
            if(res.code == 200){
              location.reload();
            }else{
              $(".alert").show().find("#msg").text(res.msg);
            }
          }
        })

      })

      
    })
  </script>
</html>
