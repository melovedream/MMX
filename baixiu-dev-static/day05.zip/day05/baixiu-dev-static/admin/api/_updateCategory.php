<?php
	//接收前端发送的请求，获取前端发送过来的参数
	//更新相应的分类数据,要求前端必须传递一个分类id
	//根据分类id来更新相应的数据
	$categoryId = $_POST["categoryId"];
	$name = $_POST["name"];
	$slug = $_POST["slug"];
	$classname = $_POST["classname"];

	$sql = " update categories set name='{$name}',slug='{$slug}',classname='{$classname}' where id = {$categoryId} ";

	//引入functions.php
	include "../../functions.php";

	//执行sql语句并得到结果
	$result = execute($sql);

	//判断sql语句是否执行成功
	if($result === true){
		$res = ["code"=>200,"msg"=>"更新成功"];
	}else{
		$res = [ "code"=>2333,"msg"=>"更新失败,".$result ];
	}

	echo json_encode($res);

?>