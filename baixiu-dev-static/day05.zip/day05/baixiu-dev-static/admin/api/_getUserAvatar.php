<?php
	//查询当前登录的这个用户的头像和名称信息。
	//如何获取当前登录的用户呢？在用户登陆的时候记录登陆的用户id就可以了

	session_start();
	//1.获取session中存储的用户id
	$userId = $_SESSION["userId"];

	//2.定义一个查询头像信息和名称信息的sql语句
	$sql = " select avatar,nickname from users where id={$userId} ";

	//3.执行sql语句
	include_once "../../functions.php";
	//执行查询并得到结果数组
	$arr = query( $sql );

	if( empty($arr) ){
		//没有数据，说明查询失败
		$res = [ "code"=>404 , "msg"=>"查询失败"];
	}else{
		$res = [ "code"=>200 , "msg"=>"查询成功","data"=>$arr ];
	}

	//将结果数组转换为json格式的字符串并输出
	echo json_encode($res);

?>