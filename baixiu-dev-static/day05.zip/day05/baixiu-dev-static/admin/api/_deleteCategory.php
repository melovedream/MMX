<?php

	//要求前端传递需要删除的分类的id
	$id = $_POST["categoryId"];

	$sql = " delete from categories where id = {$id} ";

	include "../../functions.php";

	$result = execute($sql);

	if($result === true){
		$res = ["code"=>200,"msg"=>"删除分类成功"];
	}else{
		$res = ["code"=>233,"msg"=>"删除分类失败".$result];
	}

	echo json_encode($res);

?>