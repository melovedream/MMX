<?php
	//_addCategory接口获取前端传递的名称，别名，类名来做添加分类的操作
	//不能添加重复名字的分类

	//1.获取前端发送的参数
	$name = $_POST["name"];
	$slug = $_POST["slug"];
	$classname = $_POST["classname"];

	//2.查询是否有跟前端发送的名字同名的分类，如果有，则不能添加，如果没有，才可以继续添加
	$sql = " select * from categories where name='{$name}' ";

	include_once "../../functions.php";

	//执行sql语句，查询是否有同名的数据
	$arr = query($sql);

	if(empty($arr)){
		//如果查询的结果数组arr中没有数据，说明就是没有同名的分类
		//可以继续做添加分类的操作

		$sql = " insert into categories values(null,'{$slug}','{$name}','{$classname}') ";
		//执行增加的sql语句，并得到结果
		$result = execute($sql);

		if($result === true){
			//新增成功
			$res = ["code"=>200 , "msg"=>"新增成功"];
		}else{
			//新增失败
			$res = ["code"=>234 , "msg"=>"新增失败".$result  ];
		}

	}else{
		//如果查询的结果数组arr中有数据，说明有同名的分类
		//返回给客户一个错误的提示信息
		$res = [ "code"=>233 , "msg"=>"有同名的分类，无法添加"];
	}

	//将$res转换为json格式字符串返回前端
	echo json_encode($res);

?>