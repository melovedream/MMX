<?php
	//前端会发送email账号和密码过来，后台接收前端发送的数据
	$email = $_POST["email"];
	$password = $_POST["password"];

	//定义查询的sql语句
	$sql = " select * from users where email='{$email}' and password='{$password}' and status='activated'     ";

	//引入functions.php
	include_once "../../functions.php";
	//执行sql语句得到查询的结果数组
	$arr = query( $sql );

	//判断数组中是否有内容
	if(empty( $arr )){
		$res = [ "code"=>233,"msg"=>"您输入的账号或密码有误" ];
	}else{
		$res = [ "code"=>200,"msg"=>"登录成功" ];
		session_start();
		$_SESSION["isLogin"] = "true";
		//假如用户登录成功，在session中记录当前登录的用户id，在获取头像信息的时候需要使用它
		$_SESSION["userId"] = $arr[0]["id"];

	}

	//将数组转换为json格式的字符串并输出。
	echo json_encode($res);

?>